package com.example.helloapp_justinhartwick;

import android.os.Bundle;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

/**
 * Manages the Data screen for the Writing Project Tracker.
 * Focuses on visible UI behavior only; real database logic will follow later.
 */
public class DataActivity extends AppCompatActivity {

    private GridLayout gridLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data);

        gridLayout = findViewById(R.id.gridLayout);
        Button addDataButton = findViewById(R.id.btnAddData);

        // Adds a new sample row when "Add New Entry" is pressed
        addDataButton.setOnClickListener(view -> {
            TextView newItem = new TextView(this);
            newItem.setText(getString(R.string.sample_entry)); // from strings.xml
            newItem.setPadding(8, 8, 8, 8);

            Button deleteButton = new Button(this);
            deleteButton.setText(getString(R.string.delete_button)); // from strings.xml
            deleteButton.setBackgroundTintList(
                    getResources().getColorStateList(android.R.color.holo_red_dark, getTheme()));
            deleteButton.setTextColor(
                    getResources().getColor(android.R.color.white, getTheme()));

            // Each delete button removes its matching text when tapped
            deleteButton.setOnClickListener(btnView -> {
                gridLayout.removeView(newItem);
                gridLayout.removeView(deleteButton);
                Toast.makeText(this, "Entry removed", Toast.LENGTH_SHORT).show();
            });

            // Add both views to the grid
            gridLayout.addView(newItem);
            gridLayout.addView(deleteButton);

            Toast.makeText(this, "Entry added", Toast.LENGTH_SHORT).show();
        });
    }
}
