package com.example.helloapp_justinhartwick.ui;

import android.Manifest;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.example.helloapp_justinhartwick.R;
import com.example.helloapp_justinhartwick.data.DBHelper;

import java.util.ArrayList;

// Justin Hartwick – CS360 Project Three: Writing Project Tracker App
// Main screen where writers can view, add, and manage writing sessions and deadlines.

public class MainActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_CODE = 1;
    private DBHelper dbHelper;
    private ListView eventList;
    private ArrayAdapter<String> adapter;
    private ArrayList<String> events;
    private ArrayList<Integer> eventIds;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dbHelper = new DBHelper(this);
        eventList = findViewById(R.id.listEvents);
        events = new ArrayList<>();
        eventIds = new ArrayList<>();

        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, events);
        eventList.setAdapter(adapter);

        loadEvents(); // display all saved events

        // Click to edit or delete
        eventList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                showEditDeleteDialog(eventIds.get(position));
            }
        });

        // Long click = add new
        eventList.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                showAddEventDialog();
                return true;
            }
        });

        // Ask for SMS permission on start
        checkSMSPermission();
    }

    private void loadEvents() {
        events.clear();
        eventIds.clear();

        Cursor cursor = dbHelper.getAllEvents();
        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
                String title = cursor.getString(cursor.getColumnIndexOrThrow("title"));
                String date = cursor.getString(cursor.getColumnIndexOrThrow("date"));
                String time = cursor.getString(cursor.getColumnIndexOrThrow("time"));
                events.add(title + " – " + date + " " + time);
                eventIds.add(id);
            } while (cursor.moveToNext());
        }
        cursor.close();
        adapter.notifyDataSetChanged();
    }

    private void showAddEventDialog() {
        View dialogView = getLayoutInflater().inflate(R.layout.dialog_add_event, null);
        EditText title = dialogView.findViewById(R.id.editTitle);
        EditText date = dialogView.findViewById(R.id.editDate);
        EditText time = dialogView.findViewById(R.id.editTime);
        EditText notes = dialogView.findViewById(R.id.editNotes);

        new AlertDialog.Builder(this)
                .setTitle("Add Writing Session")
                .setView(dialogView)
                .setPositiveButton("Save", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        boolean added = dbHelper.addEvent(
                                title.getText().toString(),
                                date.getText().toString(),
                                time.getText().toString(),
                                notes.getText().toString());
                        if (added) {
                            Toast.makeText(MainActivity.this, "Event added", Toast.LENGTH_SHORT).show();
                            sendSMS("New writing session added: " + title.getText().toString());
                            loadEvents();
                        } else {
                            Toast.makeText(MainActivity.this, "Error saving event", Toast.LENGTH_SHORT).show();
                        }
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void showEditDeleteDialog(int eventId) {
        View dialogView = getLayoutInflater().inflate(R.layout.dialog_add_event, null);
        EditText title = dialogView.findViewById(R.id.editTitle);
        EditText date = dialogView.findViewById(R.id.editDate);
        EditText time = dialogView.findViewById(R.id.editTime);
        EditText notes = dialogView.findViewById(R.id.editNotes);

        new AlertDialog.Builder(this)
                .setTitle("Update or Delete")
                .setView(dialogView)
                .setPositiveButton("Update", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        boolean updated = dbHelper.updateEvent(eventId,
                                title.getText().toString(),
                                date.getText().toString(),
                                time.getText().toString(),
                                notes.getText().toString());
                        if (updated) {
                            Toast.makeText(MainActivity.this, "Event updated", Toast.LENGTH_SHORT).show();
                            loadEvents();
                        } else {
                            Toast.makeText(MainActivity.this, "Update failed", Toast.LENGTH_SHORT).show();
                        }
                    }
                })
                .setNeutralButton("Delete", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        boolean deleted = dbHelper.deleteEvent(eventId);
                        if (deleted) {
                            Toast.makeText(MainActivity.this, "Event deleted", Toast.LENGTH_SHORT).show();
                            loadEvents();
                        } else {
                            Toast.makeText(MainActivity.this, "Delete failed", Toast.LENGTH_SHORT).show();
                        }
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    // Permission handling for SMS
    private void checkSMSPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.SEND_SMS},
                    SMS_PERMISSION_CODE);
        }
    }

    private void sendSMS(String message) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {
            try {
                SmsManager smsManager = SmsManager.getDefault();
                smsManager.sendTextMessage("5554", null, message, null, null);
            } catch (Exception e) {
                Toast.makeText(this, "SMS failed to send", Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "SMS permission granted", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "SMS permission denied – app still works normally", Toast.LENGTH_LONG).show();
            }
        }
    }
}
