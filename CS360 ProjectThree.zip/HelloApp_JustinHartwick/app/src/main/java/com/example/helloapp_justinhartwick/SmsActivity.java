package com.example.helloapp_justinhartwick;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

/**
 * Handles SMS permission and notification UI for the Writing Project Tracker.
 * This screen focuses on permission visuals, not real message sending.
 */
public class SmsActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_CODE = 101;
    private TextView statusText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms);

        Button checkPermissionButton = findViewById(R.id.btnCheckPermission);
        Button sendNotificationButton = findViewById(R.id.btnSendNotification);
        statusText = findViewById(R.id.tvStatus);

        // Checks if SMS permission is already granted
        checkPermissionButton.setOnClickListener(view -> {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                    == PackageManager.PERMISSION_GRANTED) {
                statusText.setText(getString(R.string.sms_permission_granted));
            } else {
                ActivityCompat.requestPermissions(
                        this,
                        new String[]{Manifest.permission.SEND_SMS},
                        SMS_PERMISSION_CODE
                );
            }
        });

        // Simulates sending a notification when permission is granted
        sendNotificationButton.setOnClickListener(view -> {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                    == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, getString(R.string.toast_notification_sent), Toast.LENGTH_SHORT).show();
                statusText.setText(getString(R.string.sms_notification_done));
            } else {
                Toast.makeText(this, getString(R.string.toast_permission_missing), Toast.LENGTH_SHORT).show();
                statusText.setText(getString(R.string.sms_permission_needed));
            }
        });
    }

    // Handles permission result and adds @NonNull annotations for clarity
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                statusText.setText(getString(R.string.sms_permission_granted_success));
            } else {
                statusText.setText(getString(R.string.sms_permission_denied));
            }
        }
    }
}
